import { CommitInfo } from "../App";
import CommitItem from "./sub_components/commititem";
import { useEffect, useState } from "react";
import { timeAgo } from "../utils";
import { FileInfo } from "../App";
import { invoke } from "@tauri-apps/api/core";
import EntryItem from "./sub_components/entryItem";

enum views {HISTORY, STAGING}

export default function MiddlePart({ commits, setSelectedCommit, repoPath, unpushedCommits }: { commits: CommitInfo[], setSelectedCommit: React.Dispatch<React.SetStateAction<CommitInfo | undefined>>, repoPath: string, unpushedCommits: CommitInfo[]}) {
    const [selected, setSelected] = useState<string>("");
    const [selectedUnpushed, setSelectedUnpushed] = useState<string>("");
    const [selectedEntry, setSelectedEntry] = useState<FileInfo>();
    const [selectedView, setSelectedView] = useState<views>(views.HISTORY);
    const [stagingFile, setStagingFiles] = useState<FileInfo[]>([]);

    function handleClick(commit: CommitInfo) {
        async function load() {
            setSelected(commit.hash);
            setSelectedCommit(commit);
        }
        load();
    }

    async function loadEntries() {
        const files = await invoke<FileInfo[]>("get_entrys", { path: repoPath });
        setStagingFiles(files);
    }

    useEffect(() => {
        loadEntries()
    }, [repoPath]) 

    return (
        <div className="w-full h-full flex flex-col bg-bg-base">
            <div className="w-fit h-16 flex flex-row justify-center items-center shrink-0 gap-2 px-3">
                <button onClick={() => setSelectedView(views.HISTORY)} className={`px-2 w-full h-fit ${selectedView === views.HISTORY ? "bg-bg-surface/50" : "bg-bg-overlay"} border border-border-subtle rounded-sm text-md text-text-primary font-mono cursor-pointer`}>History</button>
                <button onClick={() => setSelectedView(views.STAGING)} className={`px-2 w-full h-fit ${selectedView === views.STAGING ? "bg-bg-surface/50" : "bg-bg-overlay"} border border-border-subtle rounded-sm text-md text-text-primary font-mono cursor-pointer`}>Staging</button>
            </div>
            <div className="w-full h-16 shrink-0 px-3">
                <div className="w-full h-full flex items-center justify-between bg-bg-elevated rounded-sm px-3">
                    <h2 className="text-md text-text-secondary font-mono font-semibold">{selectedView === views.HISTORY ? "COMMITS" : "ENTRYS"}</h2>
                    <h2 className="text-md text-text-secondary font-mono font-semibold">{selectedView === views.HISTORY ? commits.length : stagingFile.length} SHOWN</h2>
                </div>
            </div>

            {
                selectedView === views.HISTORY ? (
                    <div className="h-full w-full flex flex-col gap-2 overflow-y-scroll p-3">
                        {commits.length > 0 ? commits.map((commit, i) =>
                            <CommitItem hash={commit.hash} message={commit.message} author={commit.author} date={timeAgo(commit.time)} tags={[]} isSelected={selected === commit.hash} isFirst={i === 0} onClick={() => handleClick(commit)} />
                        ) : null}
                    </div>
                ) : (
                    <div className="h-full w-full flex flex-col gap-2 overflow-y-scroll p-3">
                        {stagingFile.length > 0 ? stagingFile.map((entry, i) =>
                            <EntryItem key={i} repoPath={repoPath} entryFile={entry} isSelected={selectedEntry === entry} onClick={() => setSelectedEntry(entry)} onAction={loadEntries} />
                        ) : null}
                    </div>
                )
            }
            {
                unpushedCommits.length > 0 ? (
                    <div className="w-full h-2/5 bg-bg-base p-3 pt-1">
                        <div className="w-full h-full bg-bg-elevated rounded-sm">
                            <div className="w-full h-16 shrink-0 p-3">
                                <div className="w-full h-full flex items-center justify-between bg-bg-surface rounded-sm px-3">
                                    <h2 className="text-md text-text-secondary font-mono font-semibold">UNPUSHED COMMITS</h2>
                                    <h2 className="text-md text-text-secondary font-mono font-semibold">{unpushedCommits.length} SHOWN</h2>
                                </div>
                                {
                                    unpushedCommits.map((commit, i) => (
                                        <CommitItem key={i} hash={commit.hash} message={commit.message} author={commit.author} date={timeAgo(commit.time)} tags={[]} isSelected={selectedUnpushed === commit.hash} isFirst={i === 0} onClick={() => setSelectedUnpushed(commit.hash)}/>
                                    ))
                                }
                            </div>
                        </div>
                    </div>
                ) : null
            }
        </div>
    );
}