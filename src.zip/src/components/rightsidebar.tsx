import { useEffect, useState } from "react";
import { FileInfo, CommitInfo } from "../App";
import Commit from "./sub_components/commit";
import { commitStages } from "./sub_components/commit";
import { invoke } from "@tauri-apps/api/core";
import { timeAgo } from "../utils";


export default function RightSideBar({ selectedCommit, repoPath, files, setFiles, setUnpushedCommits, currentBranch }: { selectedCommit: CommitInfo | undefined, repoPath: string, files: FileInfo[], setFiles: React.Dispatch<React.SetStateAction<FileInfo[]>>, setUnpushedCommits: React.Dispatch<React.SetStateAction<CommitInfo[]>>, currentBranch: string }) {
    const [commitMessage, setCommitMessage] = useState<string>("");
    
    function GetCommitStage(status: string): commitStages {
        switch (status) {
            case "ADDED": return commitStages.NEW;
            case "DELETED": return commitStages.DELETED;
            case "RENAMED": return commitStages.RENAMED;
            case "MODIFIED": return commitStages.MODIFIED;
            case "IGNORED": return commitStages.IGNORED;
            default: return commitStages.UNTRACKED;
        }
    }

    function handleCommitInputChange(e: React.ChangeEvent<HTMLTextAreaElement>){
        setCommitMessage(e?.target.value);
    }

    const handleCommitButton = () => {
        if (!selectedCommit?.hash) return;
        async function load(){
            await invoke("make_commit", {path: repoPath, message: commitMessage});
            let unpushedCommits = await invoke<CommitInfo[]>("get_unpushed_commits", {path: repoPath, branch: currentBranch});
            setUnpushedCommits(unpushedCommits);
            setCommitMessage("");
        }
        load();
    }

    useEffect(() => {
        async function load() {
            const files = await invoke<FileInfo[]>("get_commit_files", { path: repoPath, hash: selectedCommit?.hash });
            console.log(files);
            setFiles(files);
        }
        load();
    }, [selectedCommit])

    return(
        <div className="w-full h-full bg-bg-surface flex flex-col overflow-hidden">
            <div className="w-full h-40 shrink-0 grow-0 overflow-y-scroll flex flex-col gap-3 p-3 border-b border-l border-border">
                <h2 className="text-md text-text-secondary font-mono">SELECTED COMMIT</h2>
                <h1 className="text-3xl text-text-primary font-sans font-semibold">{selectedCommit?.message}</h1>
                <div>
                <p className="text-sm text-text-muted font-mono"><span className="text-accent">{selectedCommit?.hash.slice(0, 7)}</span></p>
                    <p className="text-sm text-text-muted font-mono">{selectedCommit?.author} - {timeAgo(selectedCommit?.time)}</p>
                </div>
            </div>
            <div className="w-full h-full flex flex-col gap-3 p-3 overflow-y-scroll border-l border-border">
                <h2 className="text-md text-text-secondary font-mono">changed files</h2>
                {files.length > 0 ? files.map((file, i) => 
                    <Commit key={i} stage={GetCommitStage(file.status)} dir={file.path} />
                ) : null} 
            </div>
            <div className="w-full h-48 flex flex-col items-end justify-between gap-2 p-3 grow-0 shrink-0 overflow-hidden border-t border-l border-border">
                <h2 className="w-full flex items-center justify-start text-md text-text-secondary font-mono">push to remote</h2>
                <textarea placeholder="Type your commit message here!" value={commitMessage} onChange={handleCommitInputChange}
                    className="w-full h-full p-3 resize-none
                    outline-none border border-border flex items-start justify-start
                    bg-bg-base rounded-sm text-text-primary font-mono
                    placeholder:text-text-muted text-lg" />
                <button onClick={handleCommitButton} className="w-full h-24 border border-accent bg-accent-subtle rounded-sm text-md text-text-primary font-mono cursor-pointer transition-all duration-100 hover:bg-accent">Commit Staged</button>
            </div>
        </div>
    );
}