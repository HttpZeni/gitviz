import { CommitInfo } from "../../App";
import { invoke } from "@tauri-apps/api/core";

export default function Branch({ branchName, index, isSelected, setSelectedBranch, setCommit, repoPath, setUnpushedCommits }: { branchName: String, index: number, isSelected: boolean, setSelectedBranch: React.Dispatch<React.SetStateAction<number>>, setCommit: React.Dispatch<React.SetStateAction<CommitInfo[]>>, repoPath: string, setUnpushedCommits: React.Dispatch<React.SetStateAction<CommitInfo[]>> }) {
    const color = `branch-${(index % 6) || 6}`;

    const handleClick = () => {
        setSelectedBranch(index);
        async function load(){
            const commits = await invoke<CommitInfo[]>("get_commits_with_branch", { path: repoPath, branch: branchName });
            setCommit(commits);
            let unpushedCommits = await invoke<CommitInfo[]>("get_unpushed_commits", { path: repoPath, branch: branchName });
            setUnpushedCommits(unpushedCommits);
        }
        load();
    } 

    return (
        <div onClick={handleClick}
            className={`w-full h-10 py-1 gap-3 flex flex-row items-center justify-start cursor-pointer
        ${isSelected ? `bg-bg-overlay` : `bg-transparent px-2`} rounded-sm transition-all duration-100
        hover:text-text-primar text-sm ${isSelected ? "text-text-primary" : "text-text-secondary"} hover:bg-bg-elevated
        font-sans font-semibold`}>
            {isSelected ? <div className={`h-full px-px bg-${color} transition-all duration-100`}/> : null}
            <div className={`rounded-full bg-${color} p-1 transition-all duration-100`}></div>
            {branchName}
        </div>
    )
}