import { invoke } from "@tauri-apps/api/core";

export default function CommitItem({ repoPath, hash, message, author, date, tags, isSelected, isFirst, onClick, isLast = false, onAction }: { repoPath: string, hash: string; message: string; author: string; date: string; tags: string[]; isSelected: boolean; isFirst: boolean; isLast?: boolean; onClick: () => void; onAction: () => void }) {
    const handleClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        async function load() {
            try {
                await invoke("revert_commit", { path: repoPath, hash: hash })
                onAction();
            } catch (err) {
                console.error("revert error:", JSON.stringify(err));
            }
        }
        load();
    }
    
    return (
        <div
            onClick={onClick}
            className={`w-full flex flex-row gap-3 px-3 py-2 cursor-pointer transition-all duration-100 rounded-sm
            ${isSelected ? "bg-bg-elevated" : "hover:bg-bg-elevated"}`}>

            <div className="flex flex-col items-center shrink-0 pt-1">
                <div className={`w-2.5 h-2.5 rounded-full border-2 shrink-0
                    ${isFirst ? "border-accent bg-accent/30" : "border-border bg-transparent"}`} />
                {!isLast && <div className="w-px flex-1 bg-border mt-1 min-h-3" />}
            </div>

            <div className="flex flex-col gap-0.5 min-w-0 pb-1">
                {tags.length > 0 && (
                    <div className="flex flex-row gap-1.5 flex-wrap mb-0.5">
                        {tags.map((tag) => (
                            <span key={tag}
                                className={`text-[10px] px-1.5 py-0.5 rounded-sm font-mono font-semibold
                                    ${tag === "HEAD" ? "bg-accent-subtle text-accent" : "bg-bg-overlay text-text-secondary"}`}>
                                {tag}
                            </span>
                        ))}
                    </div>
                )}

                <p className={`text-sm font-sans truncate ${isSelected ? "text-text-primary" : "text-text-secondary"}`}>
                    {message}
                </p>

                <p className="text-xs font-mono text-text-muted">
                    <span className="text-accent/70">{hash.slice(0, 7)}</span>
                    {" · "}{author}{" · "}{date}
                </p>
            </div>

            {
                isFirst && (
                    <div className="w-full flex items-center justify-end">
                        <button onClick={handleClick} className="bg-danger border border-danger rounded py-1 px-2 transition-all duration-100 cursor-pointer font-semibold font-mono hover:bg-transparent hover:text-text-primary">{`<`}-</button>
                    </div>
                )
            }
        </div>
    );
}
